"""
배터리 열폭주 시뮬레이터 (Battery Thermal Runaway Simulator)
────────────────────────────────────────────────────────────
Streamlit 기반 인터랙티브 배터리 안전성 분석 대시보드

실행 방법:
    streamlit run app.py --server.port 8501
"""

from __future__ import annotations

import io
import math
from typing import Optional

import numpy as np
import pandas as pd
import plotly.graph_objects as go
import streamlit as st
from plotly.subplots import make_subplots

from analysis import (
    DEFAULT_THRESHOLDS,
    SafetyReport,
    add_status_column,
    compute_derived,
    generate_report,
    preprocess,
)
from generate_sample_data import generate_battery_data

# ─────────────────────────────────────────────────────────────────────────────
# 페이지 기본 설정
# ─────────────────────────────────────────────────────────────────────────────
st.set_page_config(
    page_title="배터리 열폭주 시뮬레이터",
    page_icon="🔋",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ─────────────────────────────────────────────────────────────────────────────
# 전역 CSS 스타일
# ─────────────────────────────────────────────────────────────────────────────
st.markdown(
    """
    <style>
    /* 전체 배경 */
    .stApp { background-color: #0d1117; color: #e6edf3; }

    /* 사이드바 */
    [data-testid="stSidebar"] { background-color: #161b22; }

    /* 메트릭 카드 */
    [data-testid="stMetric"] {
        background-color: #21262d;
        border: 1px solid #30363d;
        border-radius: 10px;
        padding: 12px 16px;
    }

    /* 상태 배지 */
    .status-safe {
        background: linear-gradient(135deg, #1a7f37, #2ea043);
        color: #ffffff;
        padding: 8px 20px;
        border-radius: 8px;
        font-size: 1.1rem;
        font-weight: 700;
        display: inline-block;
    }
    .status-caution {
        background: linear-gradient(135deg, #9a6700, #d29922);
        color: #ffffff;
        padding: 8px 20px;
        border-radius: 8px;
        font-size: 1.1rem;
        font-weight: 700;
        display: inline-block;
    }
    .status-danger {
        background: linear-gradient(135deg, #b91c1c, #ef4444);
        color: #ffffff;
        padding: 8px 20px;
        border-radius: 8px;
        font-size: 1.1rem;
        font-weight: 700;
        display: inline-block;
        animation: pulse 1.5s infinite;
    }
    @keyframes pulse {
        0%, 100% { opacity: 1; }
        50% { opacity: 0.75; }
    }

    /* 리포트 박스 */
    .report-box {
        background-color: #161b22;
        border: 1px solid #30363d;
        border-radius: 10px;
        padding: 20px 24px;
        margin-top: 8px;
    }
    .report-title {
        font-size: 1.05rem;
        font-weight: 700;
        color: #58a6ff;
        margin-bottom: 10px;
    }
    .report-item {
        font-size: 0.92rem;
        color: #c9d1d9;
        margin: 4px 0;
        padding-left: 8px;
        border-left: 3px solid #30363d;
    }
    .highlight-green { color: #3fb950; font-weight: 600; }
    .highlight-yellow { color: #d29922; font-weight: 600; }
    .highlight-red { color: #f85149; font-weight: 600; }

    /* 구분선 */
    hr { border-color: #30363d; }

    /* 경고 박스 */
    .warn-box {
        background-color: #2d1b00;
        border: 1px solid #d29922;
        border-radius: 8px;
        padding: 10px 14px;
        color: #e3b341;
        font-size: 0.88rem;
        margin: 6px 0;
    }
    </style>
    """,
    unsafe_allow_html=True,
)

# ─────────────────────────────────────────────────────────────────────────────
# 헬퍼 함수
# ─────────────────────────────────────────────────────────────────────────────

STATUS_LABEL = {
    "safe": "✅ 정상 (Safe)",
    "caution": "⚠️ 주의 (Caution)",
    "danger": "🚨 위험 — 열폭주 (Thermal Runaway)",
}
STATUS_COLOR = {"safe": "status-safe", "caution": "status-caution", "danger": "status-danger"}
STATUS_GAUGE_COLOR = {
    "safe": ["#1a7f37", "#2ea043"],
    "caution": ["#9a6700", "#d29922"],
    "danger": ["#b91c1c", "#ef4444"],
}
PLOTLY_BG = "#0d1117"
PLOTLY_PAPER = "#0d1117"
PLOTLY_FONT = "#e6edf3"
PLOTLY_GRID = "#21262d"


def fmt_time(seconds: Optional[float]) -> str:
    if seconds is None:
        return "해당 없음"
    m, s = divmod(int(seconds), 60)
    h, m = divmod(m, 60)
    if h > 0:
        return f"{h}시간 {m}분 {s}초"
    return f"{m}분 {s}초"


def plotly_base_layout(title: str = "") -> dict:
    return dict(
        title=dict(text=title, font=dict(color=PLOTLY_FONT, size=14)),
        paper_bgcolor=PLOTLY_PAPER,
        plot_bgcolor=PLOTLY_BG,
        font=dict(color=PLOTLY_FONT, size=11),
        xaxis=dict(gridcolor=PLOTLY_GRID, zerolinecolor=PLOTLY_GRID),
        yaxis=dict(gridcolor=PLOTLY_GRID, zerolinecolor=PLOTLY_GRID),
        legend=dict(bgcolor="#161b22", bordercolor="#30363d", borderwidth=1),
        margin=dict(l=50, r=30, t=50, b=40),
    )


# ─────────────────────────────────────────────────────────────────────────────
# 게이지 차트 (상태 인디케이터)
# ─────────────────────────────────────────────────────────────────────────────

def make_gauge_chart(report: SafetyReport, thresholds: dict) -> go.Figure:
    max_temp = thresholds["temp_caution_max"] * 1.5
    value = min(report.max_temp, max_temp)

    colors = STATUS_GAUGE_COLOR[report.overall_status]
    bar_color = colors[1]

    fig = go.Figure(
        go.Indicator(
            mode="gauge+number+delta",
            value=report.max_temp,
            number=dict(suffix="°C", font=dict(size=36, color=PLOTLY_FONT)),
            delta=dict(
                reference=thresholds["temp_safe_max"],
                increasing=dict(color="#f85149"),
                decreasing=dict(color="#3fb950"),
                font=dict(size=14),
            ),
            title=dict(text="최고 온도", font=dict(size=14, color=PLOTLY_FONT)),
            gauge=dict(
                axis=dict(
                    range=[0, max_temp],
                    tickwidth=1,
                    tickcolor=PLOTLY_FONT,
                    tickfont=dict(color=PLOTLY_FONT, size=10),
                ),
                bar=dict(color=bar_color, thickness=0.25),
                bgcolor="#21262d",
                borderwidth=0,
                steps=[
                    dict(range=[0, thresholds["temp_safe_max"]], color="#1a3a1a"),
                    dict(
                        range=[thresholds["temp_safe_max"], thresholds["temp_caution_max"]],
                        color="#3a2a00",
                    ),
                    dict(range=[thresholds["temp_caution_max"], max_temp], color="#3a0a0a"),
                ],
                threshold=dict(
                    line=dict(color="#f85149", width=3),
                    thickness=0.75,
                    value=thresholds["temp_caution_max"],
                ),
            ),
        )
    )
    fig.update_layout(
        paper_bgcolor=PLOTLY_PAPER,
        font=dict(color=PLOTLY_FONT),
        margin=dict(l=30, r=30, t=30, b=10),
        height=240,
    )
    return fig


# ─────────────────────────────────────────────────────────────────────────────
# 상태 비율 도넛 차트
# ─────────────────────────────────────────────────────────────────────────────

def make_donut_chart(report: SafetyReport) -> go.Figure:
    labels = ["정상", "주의", "위험"]
    values = [
        report.safe_ratio * 100,
        report.caution_ratio * 100,
        report.danger_ratio * 100,
    ]
    colors = ["#2ea043", "#d29922", "#ef4444"]

    fig = go.Figure(
        go.Pie(
            labels=labels,
            values=values,
            hole=0.55,
            marker=dict(colors=colors, line=dict(color="#0d1117", width=2)),
            textfont=dict(size=11, color="#ffffff"),
            hovertemplate="%{label}: %{value:.1f}%<extra></extra>",
        )
    )
    fig.update_layout(
        paper_bgcolor=PLOTLY_PAPER,
        font=dict(color=PLOTLY_FONT),
        margin=dict(l=10, r=10, t=30, b=10),
        height=240,
        showlegend=True,
        legend=dict(
            orientation="v",
            bgcolor="#161b22",
            bordercolor="#30363d",
            borderwidth=1,
            font=dict(size=10),
        ),
        annotations=[
            dict(
                text=f"{report.safe_ratio*100:.0f}%<br>정상",
                x=0.5, y=0.5,
                font=dict(size=13, color=PLOTLY_FONT),
                showarrow=False,
            )
        ],
    )
    return fig


# ─────────────────────────────────────────────────────────────────────────────
# 온도·전압 듀얼 축 그래프
# ─────────────────────────────────────────────────────────────────────────────

def make_temp_voltage_chart(df: pd.DataFrame, thresholds: dict) -> go.Figure:
    fig = make_subplots(specs=[[{"secondary_y": True}]])

    x = df["Time"] / 60  # 분 단위

    # ── 배경 음영 (위험 구간) ────────────────────────────────────────────
    caution_mask = df["Temperature"] > thresholds["temp_safe_max"]
    danger_mask = df["Temperature"] > thresholds["temp_caution_max"]

    def add_shading(mask: pd.Series, color: str, name: str):
        """연속 구간을 vrect 대신 scatter fill로 추가"""
        in_zone = False
        x_start = None
        for i, val in enumerate(mask):
            if val and not in_zone:
                in_zone = True
                x_start = x.iloc[i]
            elif not val and in_zone:
                in_zone = False
                fig.add_vrect(
                    x0=x_start, x1=x.iloc[i - 1],
                    fillcolor=color, opacity=0.15,
                    layer="below", line_width=0,
                )
        if in_zone:
            fig.add_vrect(
                x0=x_start, x1=x.iloc[-1],
                fillcolor=color, opacity=0.15,
                layer="below", line_width=0,
            )

    add_shading(caution_mask & ~danger_mask, "#d29922", "주의 구간")
    add_shading(danger_mask, "#ef4444", "위험 구간")

    # ── 임계선 ───────────────────────────────────────────────────────────
    fig.add_hline(
        y=thresholds["temp_safe_max"],
        line=dict(color="#d29922", dash="dash", width=1.5),
        annotation_text=f"주의 임계 {thresholds['temp_safe_max']}°C",
        annotation_font=dict(color="#d29922", size=10),
        annotation_position="top left",
    )
    fig.add_hline(
        y=thresholds["temp_caution_max"],
        line=dict(color="#ef4444", dash="dash", width=1.5),
        annotation_text=f"위험 임계 {thresholds['temp_caution_max']}°C",
        annotation_font=dict(color="#ef4444", size=10),
        annotation_position="top left",
    )

    # ── 온도 곡선 ────────────────────────────────────────────────────────
    fig.add_trace(
        go.Scatter(
            x=x, y=df["Temperature"],
            name="온도 (°C)",
            line=dict(color="#ff7b72", width=2),
            hovertemplate="시간: %{x:.1f}분<br>온도: %{y:.1f}°C<extra></extra>",
        ),
        secondary_y=False,
    )
    # 스무딩 곡선
    fig.add_trace(
        go.Scatter(
            x=x, y=df["Temp_smooth"],
            name="온도 (평활화)",
            line=dict(color="#ffa198", width=1.5, dash="dot"),
            hovertemplate="시간: %{x:.1f}분<br>평활 온도: %{y:.1f}°C<extra></extra>",
        ),
        secondary_y=False,
    )

    # ── 전압 곡선 ────────────────────────────────────────────────────────
    fig.add_trace(
        go.Scatter(
            x=x, y=df["Voltage"],
            name="전압 (V)",
            line=dict(color="#58a6ff", width=2),
            hovertemplate="시간: %{x:.1f}분<br>전압: %{y:.3f}V<extra></extra>",
        ),
        secondary_y=True,
    )

    # ── 레이아웃 ─────────────────────────────────────────────────────────
    fig.update_layout(
        **plotly_base_layout("온도 및 전압 변화"),
        height=380,
        hovermode="x unified",
    )
    fig.update_xaxes(title_text="시간 (분)", gridcolor=PLOTLY_GRID)
    fig.update_yaxes(title_text="온도 (°C)", gridcolor=PLOTLY_GRID, secondary_y=False)
    fig.update_yaxes(
        title_text="전압 (V)",
        gridcolor=PLOTLY_GRID,
        secondary_y=True,
        range=[2.4, 4.4],
    )
    return fig


# ─────────────────────────────────────────────────────────────────────────────
# 전류·SOC 그래프
# ─────────────────────────────────────────────────────────────────────────────

def make_current_soc_chart(df: pd.DataFrame, thresholds: dict) -> go.Figure:
    fig = make_subplots(specs=[[{"secondary_y": True}]])
    x = df["Time"] / 60

    # 안전 전류 범위 음영
    fig.add_hrect(
        y0=thresholds["current_safe_min"],
        y1=thresholds["current_safe_max"],
        fillcolor="#1a3a1a",
        opacity=0.3,
        layer="below",
        line_width=0,
        annotation_text="안전 전류 범위",
        annotation_font=dict(color="#3fb950", size=9),
        annotation_position="top left",
    )

    fig.add_trace(
        go.Scatter(
            x=x, y=df["Current"],
            name="전류 (A)",
            line=dict(color="#3fb950", width=2),
            hovertemplate="시간: %{x:.1f}분<br>전류: %{y:.2f}A<extra></extra>",
        ),
        secondary_y=False,
    )
    fig.add_trace(
        go.Scatter(
            x=x, y=df["SOC"],
            name="SOC (%)",
            line=dict(color="#a371f7", width=2),
            fill="tozeroy",
            fillcolor="rgba(163,113,247,0.08)",
            hovertemplate="시간: %{x:.1f}분<br>SOC: %{y:.1f}%<extra></extra>",
        ),
        secondary_y=True,
    )

    # SOC 경고선
    fig.add_hline(
        y=thresholds["soc_min"],
        line=dict(color="#ef4444", dash="dash", width=1),
        annotation_text=f"최소 SOC {thresholds['soc_min']}%",
        annotation_font=dict(color="#ef4444", size=9),
        annotation_position="bottom right",
        secondary_y=True,
    )

    fig.update_layout(
        **plotly_base_layout("전류 및 SOC 변화"),
        height=340,
        hovermode="x unified",
    )
    fig.update_xaxes(title_text="시간 (분)", gridcolor=PLOTLY_GRID)
    fig.update_yaxes(title_text="전류 (A)", gridcolor=PLOTLY_GRID, secondary_y=False)
    fig.update_yaxes(
        title_text="SOC (%)",
        gridcolor=PLOTLY_GRID,
        secondary_y=True,
        range=[0, 110],
    )
    return fig


# ─────────────────────────────────────────────────────────────────────────────
# dT/dt 그래프
# ─────────────────────────────────────────────────────────────────────────────

def make_dtdt_chart(df: pd.DataFrame, thresholds: dict) -> go.Figure:
    x = df["Time"] / 60
    dtdt_abs = df["dT_dt"].abs()

    fig = go.Figure()

    # 위험 임계선
    fig.add_hline(
        y=thresholds["dtdt_danger"],
        line=dict(color="#ef4444", dash="dash", width=1.5),
        annotation_text=f"위험 dT/dt {thresholds['dtdt_danger']}°C/s",
        annotation_font=dict(color="#ef4444", size=10),
        annotation_position="top left",
    )

    # 색상 구분 (임계 초과 구간 강조)
    colors = ["#ef4444" if v > thresholds["dtdt_danger"] else "#58a6ff" for v in dtdt_abs]

    fig.add_trace(
        go.Bar(
            x=x, y=dtdt_abs,
            name="|dT/dt| (°C/s)",
            marker_color=colors,
            hovertemplate="시간: %{x:.1f}분<br>|dT/dt|: %{y:.4f}°C/s<extra></extra>",
        )
    )

    fig.update_layout(
        **plotly_base_layout("온도 변화율 |dT/dt|"),
        height=280,
        bargap=0,
    )
    fig.update_xaxes(title_text="시간 (분)", gridcolor=PLOTLY_GRID)
    fig.update_yaxes(title_text="|dT/dt| (°C/s)", gridcolor=PLOTLY_GRID)
    return fig


# ─────────────────────────────────────────────────────────────────────────────
# 안전성 리포트 렌더링
# ─────────────────────────────────────────────────────────────────────────────

def render_safety_report(report: SafetyReport, thresholds: dict):
    """Streamlit 네이티브 컴포넌트로 안전성 리포트를 렌더링합니다."""
    rec_min = report.recommended_current_min
    rec_max = report.recommended_current_max

    # 상태 레이블 매핑
    status_label_ko = {"safe": "✅ 정상 (Safe)", "caution": "⚠️ 주의 (Caution)", "danger": "🚨 위험 — 열폭주 (Thermal Runaway)"}

    # 상단 헤더 박스
    st.markdown(
        '<div style="background:#161b22;border:1px solid #30363d;border-radius:10px;padding:16px 20px;">',
        unsafe_allow_html=True,
    )
    st.markdown("**📋 배터리 안전성 종합 리포트**")
    st.markdown(f"포괄 상태: **{status_label_ko[report.overall_status]}**")
    st.divider()

    # 주요 수치 로우
    c1, c2, c3, c4 = st.columns(4)
    with c1:
        temp_icon = "🔴" if report.max_temp > thresholds["temp_caution_max"] else "🟡" if report.max_temp > thresholds["temp_safe_max"] else "🟢"
        st.metric(f"{temp_icon} 최고 온도", f"{report.max_temp:.1f}°C",
                  delta=f"임계 {thresholds['temp_caution_max']}°C", delta_color="off")
    with c2:
        volt_icon = "🔴" if report.min_voltage < thresholds["voltage_min"] else "🟢"
        st.metric(f"{volt_icon} 최저 전압", f"{report.min_voltage:.3f}V",
                  delta=f"하한 {thresholds['voltage_min']}V", delta_color="off")
    with c3:
        dtdt_icon = "🔴" if report.max_dtdt > thresholds["dtdt_danger"] else "🟢"
        st.metric(f"{dtdt_icon} 최대 dT/dt", f"{report.max_dtdt:.4f}°C/s",
                  delta=f"임계 {thresholds['dtdt_danger']}°C/s", delta_color="off")
    with c4:
        st.metric("🔋 평균 전류", f"{report.avg_current:.2f}A")

    st.divider()
    st.markdown("**💡 안전 이용 가이드**")

    g1, g2 = st.columns(2)
    with g1:
        st.info(
            f"🔋 **안전 최적 충방전 전류 범위**: `{rec_min:.2f}A ~ {rec_max:.2f}A`\n\n"
            f"🌡️ **최대 허용 온도**: `{report.max_allowed_temp:.0f}°C` (이를 초과하면 열폭주 위험 급증)\n\n"
            f"🔋 **권장 SOC 범위**: `{thresholds['soc_min']:.0f}% ~ {thresholds['soc_max']:.0f}%` (과방전/과충전 방지)"
        )
    with g2:
        caution_str = fmt_time(report.caution_start_time)
        danger_str = fmt_time(report.danger_start_time)
        if report.danger_start_time:
            st.error(
                f"⚠️ **주의 구간 진입**: {caution_str}\n\n"
                f"🚨 **위험 구간 진입**: {danger_str}\n\n"
                f"📊 정상 {report.safe_ratio*100:.1f}% | 주의 {report.caution_ratio*100:.1f}% | 위험 {report.danger_ratio*100:.1f}%"
            )
        elif report.caution_start_time:
            st.warning(
                f"⚠️ **주의 구간 진입**: {caution_str}\n\n"
                f"✅ 위험 구간: 해당 없음\n\n"
                f"📊 정상 {report.safe_ratio*100:.1f}% | 주의 {report.caution_ratio*100:.1f}%"
            )
        else:
            st.success(
                f"✅ 주의/위험 구간 없음\n\n"
                f"📊 정상 {report.safe_ratio*100:.1f}%"
            )

    st.markdown('</div>', unsafe_allow_html=True)


# ─────────────────────────────────────────────────────────────────────────────
# 데이터 테이블 렌더링
# ─────────────────────────────────────────────────────────────────────────────

def render_data_table(df: pd.DataFrame):
    display_df = df[["Time", "Voltage", "Current", "Temperature", "SOC", "dT_dt", "Status"]].copy()
    display_df["Time"] = display_df["Time"].apply(lambda s: f"{int(s//60):02d}:{int(s%60):02d}")
    display_df.columns = ["시간(mm:ss)", "전압(V)", "전류(A)", "온도(°C)", "SOC(%)", "dT/dt(°C/s)", "상태"]

    def color_status(val):
        if val == "danger":
            return "background-color: #3a0a0a; color: #f85149"
        elif val == "caution":
            return "background-color: #2d1b00; color: #e3b341"
        return "background-color: #0d2a0d; color: #3fb950"

    # pandas 2.x 호환: applymap → map
    try:
        styled = display_df.style.map(color_status, subset=["상태"])
    except AttributeError:
        styled = display_df.style.applymap(color_status, subset=["상태"])
    st.dataframe(styled, use_container_width=True, height=300)


# ─────────────────────────────────────────────────────────────────────────────
# 사이드바
# ─────────────────────────────────────────────────────────────────────────────

def render_sidebar() -> dict:
    st.sidebar.markdown(
        """
        <div style="text-align:center; padding: 10px 0 20px 0;">
            <div style="font-size:2rem;">🔋</div>
            <div style="font-size:1.1rem; font-weight:700; color:#58a6ff;">
                Battery Thermal Runaway<br>Simulator
            </div>
            <div style="font-size:0.75rem; color:#8b949e; margin-top:4px;">
                v1.0 · Python + Streamlit
            </div>
        </div>
        """,
        unsafe_allow_html=True,
    )

    st.sidebar.markdown("### ⚙️ 임계값 설정")
    st.sidebar.markdown("슬라이더를 조절하여 안전 기준을 변경하세요.")

    thresholds = {}

    with st.sidebar.expander("🌡️ 온도 임계값", expanded=True):
        thresholds["temp_safe_max"] = st.slider(
            "정상 상한 온도 (°C)", 30.0, 60.0,
            float(DEFAULT_THRESHOLDS["temp_safe_max"]), 0.5,
            help="이 온도를 초과하면 '주의' 상태로 전환됩니다.",
        )
        thresholds["temp_caution_max"] = st.slider(
            "위험 임계 온도 (°C)",
            thresholds["temp_safe_max"] + 1.0, 100.0,
            max(float(DEFAULT_THRESHOLDS["temp_caution_max"]), thresholds["temp_safe_max"] + 1.0),
            0.5,
            help="이 온도를 초과하면 '위험(열폭주)' 상태로 전환됩니다.",
        )
        thresholds["dtdt_danger"] = st.slider(
            "위험 온도 상승률 (°C/s)", 0.1, 5.0,
            float(DEFAULT_THRESHOLDS["dtdt_danger"]), 0.1,
            help="분당 온도 상승률이 이 값을 초과하면 위험으로 판단합니다.",
        )

    with st.sidebar.expander("⚡ 전압 / 전류 임계값"):
        thresholds["voltage_min"] = st.slider(
            "최소 허용 전압 (V)", 2.0, 3.5,
            float(DEFAULT_THRESHOLDS["voltage_min"]), 0.05,
        )
        thresholds["voltage_max"] = st.slider(
            "최대 허용 전압 (V)", 4.0, 4.5,
            float(DEFAULT_THRESHOLDS["voltage_max"]), 0.05,
        )
        thresholds["current_safe_min"] = st.slider(
            "안전 방전 전류 하한 (A)", -20.0, 0.0,
            float(DEFAULT_THRESHOLDS["current_safe_min"]), 0.5,
        )
        thresholds["current_safe_max"] = st.slider(
            "안전 충전 전류 상한 (A)", 0.0, 20.0,
            float(DEFAULT_THRESHOLDS["current_safe_max"]), 0.5,
        )

    with st.sidebar.expander("🔋 SOC 범위"):
        thresholds["soc_min"] = st.slider(
            "최소 권장 SOC (%)", 0.0, 30.0,
            float(DEFAULT_THRESHOLDS["soc_min"]), 1.0,
        )
        thresholds["soc_max"] = st.slider(
            "최대 권장 SOC (%)", 70.0, 100.0,
            float(DEFAULT_THRESHOLDS["soc_max"]), 1.0,
        )

    st.sidebar.markdown("---")
    st.sidebar.markdown("### 📥 샘플 데이터 다운로드")

    scenario = st.sidebar.selectbox(
        "시나리오 선택",
        ["thermal_runaway", "caution", "normal"],
        format_func=lambda x: {
            "thermal_runaway": "🚨 열폭주 시나리오",
            "caution": "⚠️ 주의 시나리오",
            "normal": "✅ 정상 시나리오",
        }[x],
    )

    sample_df = generate_battery_data(scenario=scenario)
    buf = io.BytesIO()
    with pd.ExcelWriter(buf, engine="xlsxwriter") as writer:
        sample_df.to_excel(writer, index=False, sheet_name="BatteryData")
    st.sidebar.download_button(
        label="⬇️ 샘플 Excel 다운로드",
        data=buf.getvalue(),
        file_name=f"sample_{scenario}.xlsx",
        mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    )

    return thresholds


# ─────────────────────────────────────────────────────────────────────────────
# 메인 앱
# ─────────────────────────────────────────────────────────────────────────────

def main():
    thresholds = render_sidebar()

    # ── 헤더 ─────────────────────────────────────────────────────────────
    st.markdown(
        """
        <h1 style="font-size:1.8rem; font-weight:800; color:#e6edf3; margin-bottom:4px;">
            🔋 배터리 열폭주 시뮬레이터
        </h1>
        <p style="color:#8b949e; font-size:0.9rem; margin-bottom:20px;">
            Battery Thermal Runaway Simulator — 실시간 안전성 분석 대시보드
        </p>
        """,
        unsafe_allow_html=True,
    )

    # ── 파일 업로드 ───────────────────────────────────────────────────────
    st.markdown("#### 📂 데이터 업로드")
    col_up1, col_up2 = st.columns([3, 1])
    with col_up1:
        uploaded = st.file_uploader(
            "배터리 테스트 데이터 파일을 업로드하세요 (.xlsx 또는 .csv)",
            type=["xlsx", "csv"],
            help="필수 열: Time, Voltage, Current, Temperature, SOC\n"
                 "누락된 열은 기본값으로 자동 처리됩니다.",
        )
    with col_up2:
        use_demo = st.checkbox("데모 데이터 사용", value=True, help="파일 없이 내장 열폭주 시나리오 데이터를 사용합니다.")

    # ── 데이터 로드 ───────────────────────────────────────────────────────
    raw_df: Optional[pd.DataFrame] = None
    load_warnings: list[str] = []

    if uploaded is not None:
        try:
            if uploaded.name.endswith(".csv"):
                raw_df = pd.read_csv(uploaded)
            else:
                raw_df = pd.read_excel(uploaded)
            st.success(f"✅ 파일 로드 완료: **{uploaded.name}** ({len(raw_df):,}행)")
        except Exception as e:
            st.error(f"파일 읽기 오류: {e}")
    elif use_demo:
        raw_df = generate_battery_data(scenario="thermal_runaway")
        st.info("ℹ️ 내장 열폭주 시나리오 데모 데이터를 사용 중입니다. 실제 파일을 업로드하면 해당 데이터로 분석됩니다.")

    if raw_df is None:
        st.markdown(
            """
            <div style="text-align:center; padding:60px 0; color:#8b949e;">
                <div style="font-size:3rem;">📁</div>
                <p>데이터 파일을 업로드하거나 '데모 데이터 사용'을 체크하세요.</p>
            </div>
            """,
            unsafe_allow_html=True,
        )
        return

    # ── 전처리 ────────────────────────────────────────────────────────────
    df, preprocess_warns = preprocess(raw_df)
    df = compute_derived(df)
    df = add_status_column(df, thresholds)
    report = generate_report(df, thresholds)

    all_warnings = load_warnings + preprocess_warns
    if all_warnings:
        for w in all_warnings:
            st.markdown(f'<div class="warn-box">⚠️ {w}</div>', unsafe_allow_html=True)

    st.markdown("---")

    # ── 상단 상태 인디케이터 ──────────────────────────────────────────────
    st.markdown("#### 🔍 배터리 현재 상태")
    col_g1, col_g2, col_g3, col_g4, col_g5 = st.columns([2, 2, 1.2, 1.2, 1.2])

    with col_g1:
        st.plotly_chart(make_gauge_chart(report, thresholds), use_container_width=True)

    with col_g2:
        st.plotly_chart(make_donut_chart(report), use_container_width=True)

    with col_g3:
        status_label_map = {"safe": "정상", "caution": "주의", "danger": "위험"}
        delta_temp = report.max_temp - thresholds["temp_safe_max"]
        st.metric(
            "종합 상태",
            status_label_map[report.overall_status],
            delta=f"{delta_temp:+.1f}°C vs 정상 상한",
            delta_color="inverse",
        )
        st.metric("최고 온도", f"{report.max_temp:.1f}°C")

    with col_g4:
        st.metric("최저 전압", f"{report.min_voltage:.3f}V",
                  delta=f"{report.min_voltage - thresholds['voltage_min']:+.3f}V vs 하한",
                  delta_color="normal")
        st.metric("평균 전류", f"{report.avg_current:.2f}A")

    with col_g5:
        st.metric("정상 비율", f"{report.safe_ratio*100:.1f}%")
        st.metric("위험 비율", f"{report.danger_ratio*100:.1f}%",
                  delta=f"{report.danger_ratio*100:.1f}%",
                  delta_color="inverse")

    st.markdown("---")

    # ── 그래프 탭 ─────────────────────────────────────────────────────────
    st.markdown("#### 📈 데이터 시각화")
    tab1, tab2, tab3 = st.tabs(["🌡️ 온도 & 전압", "⚡ 전류 & SOC", "📊 온도 변화율 (dT/dt)"])

    with tab1:
        st.plotly_chart(make_temp_voltage_chart(df, thresholds), use_container_width=True)
        st.caption(
            "노란 음영: 주의 구간 (온도 > 정상 상한) &nbsp;|&nbsp; "
            "빨간 음영: 위험 구간 (온도 > 위험 임계)"
        )

    with tab2:
        st.plotly_chart(make_current_soc_chart(df, thresholds), use_container_width=True)
        st.caption("초록 음영: 안전 전류 범위")

    with tab3:
        st.plotly_chart(make_dtdt_chart(df, thresholds), use_container_width=True)
        st.caption("빨간 막대: 위험 임계 초과 구간")

    st.markdown("---")

    # ── 안전성 리포트 ─────────────────────────────────────────────────────
    st.markdown("#### 📋 안전성 분석 리포트")
    render_safety_report(report, thresholds)

    st.markdown("---")

    # ── 원시 데이터 테이블 ────────────────────────────────────────────────
    with st.expander("🗂️ 원시 데이터 테이블 보기", expanded=False):
        render_data_table(df)

        # CSV 다운로드
        csv_buf = io.StringIO()
        df.to_csv(csv_buf, index=False)
        st.download_button(
            "⬇️ 분석 결과 CSV 다운로드",
            data=csv_buf.getvalue(),
            file_name="battery_analysis_result.csv",
            mime="text/csv",
        )

    # ── 푸터 ─────────────────────────────────────────────────────────────
    st.markdown(
        """
        <hr style="border-color:#30363d; margin-top:30px;"/>
        <div style="text-align:center; color:#8b949e; font-size:0.78rem; padding-bottom:20px;">
            Battery Thermal Runaway Simulator · Python 3.10+ · Streamlit · Plotly<br>
            ⚠️ 본 시뮬레이터는 교육·연구 목적으로 제작되었습니다. 실제 배터리 안전 관리에는 공인된 BMS를 사용하세요.
        </div>
        """,
        unsafe_allow_html=True,
    )


if __name__ == "__main__":
    main()
