# 🔋 배터리 열폭주 시뮬레이터 (Battery Thermal Runaway Simulator)

Python + Streamlit 기반 배터리 안전성 분석 및 열폭주 예측 인터랙티브 대시보드입니다.

---

## 📁 프로젝트 구조

```
battery_simulator/
├── app.py                    # Streamlit 메인 애플리케이션
├── analysis.py               # 핵심 분석 로직 (전처리, 상태 분류, 리포트 생성)
├── generate_sample_data.py   # 시나리오별 샘플 데이터 생성기
├── sample_battery_data.xlsx  # 열폭주 시나리오 샘플 데이터 (720행)
└── README.md                 # 이 파일
```

---

## ⚙️ 설치 및 실행

### 1. 의존성 패키지 설치

```bash
pip install streamlit plotly pandas numpy openpyxl xlsxwriter
```

### 2. 앱 실행

```bash
cd battery_simulator
streamlit run app.py
```

브라우저에서 `http://localhost:8501`로 접속합니다.

### 3. 백그라운드 실행 (서버 환경)

```bash
nohup streamlit run app.py --server.port 8501 --server.headless true --server.address 0.0.0.0 &
```

---

## 🚀 주요 기능

### 1. 데이터 업로드
- `.xlsx` 또는 `.csv` 파일 업로드 지원
- 필수 열: `Time`, `Voltage`, `Current`, `Temperature`, `SOC`
- 한국어 열 이름 자동 인식 (`시간`, `전압`, `전류`, `온도`, `충전율`)
- 누락 열은 기본값으로 자동 처리, 결측값은 선형 보간 처리

### 2. 인터랙티브 시각화 (3개 탭)
| 탭 | 내용 |
|---|---|
| 🌡️ 온도 & 전압 | 듀얼 축 그래프, 주의/위험 구간 색상 음영 표시 |
| ⚡ 전류 & SOC | 안전 전류 범위 음영, SOC 면적 그래프 |
| 📊 온도 변화율 | \|dT/dt\| 막대 그래프, 위험 임계 초과 구간 강조 |

### 3. 안전성 분석 리포트
- 종합 상태 판정: **정상 / 주의 / 위험(열폭주)**
- 최고 온도, 최저 전압, 최대 dT/dt, 평균 전류 표시
- 안전 최적 충방전 전류 범위 자동 산출
- 주의/위험 구간 최초 진입 시각 표시

### 4. 상태 인디케이터 (대시보드 상단)
- **게이지 차트**: 최고 온도를 시각적으로 표시
- **도넛 차트**: 정상/주의/위험 구간 비율
- **메트릭 카드**: 종합 상태, 전압, 전류, SOC 비율

### 5. 사이드바 시뮬레이션 슬라이더
| 슬라이더 | 기본값 | 범위 |
|---|---|---|
| 정상 상한 온도 | 45°C | 30~60°C |
| 위험 임계 온도 | 60°C | 46~100°C |
| 위험 온도 상승률 | 1.0°C/s | 0.1~5.0°C/s |
| 최소 허용 전압 | 2.8V | 2.0~3.5V |
| 최대 허용 전압 | 4.25V | 4.0~4.5V |
| 안전 방전 전류 하한 | -5.0A | -20~0A |
| 안전 충전 전류 상한 | 5.0A | 0~20A |
| 최소 권장 SOC | 10% | 0~30% |
| 최대 권장 SOC | 90% | 70~100% |

---

## 📊 안전 기준 (기본값)

```python
# analysis.py 내 DEFAULT_THRESHOLDS 딕셔너리에서 수정 가능
DEFAULT_THRESHOLDS = {
    "temp_safe_max": 45.0,       # °C — 정상 상한
    "temp_caution_max": 60.0,    # °C — 주의 상한 (초과 시 위험)
    "dtdt_danger": 1.0,          # °C/s — 온도 상승률 위험 임계
    "voltage_min": 2.8,          # V — 최소 허용 전압
    "voltage_max": 4.25,         # V — 최대 허용 전압
    "current_safe_min": -5.0,    # A — 안전 방전 전류 하한
    "current_safe_max": 5.0,     # A — 안전 충전 전류 상한
    "soc_min": 10.0,             # % — 최소 권장 SOC
    "soc_max": 90.0,             # % — 최대 권장 SOC
}
```

---

## 📂 데이터 형식 예시

| Time | Voltage | Current | Temperature | SOC |
|------|---------|---------|-------------|-----|
| 0    | 4.18    | -2.01   | 25.3        | 99.8 |
| 10   | 4.17    | -2.00   | 25.5        | 99.5 |
| ...  | ...     | ...     | ...         | ... |

- **Time**: 초(seconds) 단위
- **Voltage**: 볼트(V) 단위
- **Current**: 암페어(A) 단위, 방전 시 음수
- **Temperature**: 섭씨(°C) 단위
- **SOC**: 퍼센트(%) 단위, 0~100

---

## 🧪 샘플 데이터 생성

```python
from generate_sample_data import generate_battery_data

# 열폭주 시나리오 (정상 → 주의 → 위험)
df = generate_battery_data(scenario="thermal_runaway", duration_minutes=120)

# 정상 시나리오
df = generate_battery_data(scenario="normal")

# 주의 시나리오
df = generate_battery_data(scenario="caution")
```

---

## ⚠️ 면책 조항

본 시뮬레이터는 교육·연구 목적으로 제작되었습니다. 실제 배터리 안전 관리에는 공인된 BMS(Battery Management System)를 사용하시기 바랍니다.
