"""
배터리 열폭주 시뮬레이터 - 핵심 분석 로직
안전성 판단, 임계값 감지, 요약 리포트 생성 기능을 제공합니다.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

import numpy as np
import pandas as pd


# ─────────────────────────────────────────────────────────────────────────────
# 안전 기준 상수 (사용자가 사이드바 슬라이더로 재정의 가능)
# ─────────────────────────────────────────────────────────────────────────────
DEFAULT_THRESHOLDS = {
    "temp_safe_max": 45.0,       # °C  — 정상 상한
    "temp_caution_max": 60.0,    # °C  — 주의 상한 (초과 시 위험)
    "dtdt_danger": 1.0,          # °C/s — 분당 온도 상승률 위험 임계값
    "voltage_min": 2.8,          # V   — 최소 허용 전압
    "voltage_max": 4.25,         # V   — 최대 허용 전압
    "current_safe_min": -5.0,    # A   — 안전 방전 전류 하한
    "current_safe_max": 5.0,     # A   — 안전 충전 전류 상한
    "soc_min": 10.0,             # %   — 최소 권장 SOC
    "soc_max": 90.0,             # %   — 최대 권장 SOC
}


# ─────────────────────────────────────────────────────────────────────────────
# 데이터 전처리
# ─────────────────────────────────────────────────────────────────────────────
REQUIRED_COLUMNS = {
    "Time": 0.0,
    "Voltage": 3.7,
    "Current": 0.0,
    "Temperature": 25.0,
    "SOC": 50.0,
}

COLUMN_ALIASES = {
    "time": "Time",
    "시간": "Time",
    "voltage": "Voltage",
    "전압": "Voltage",
    "current": "Current",
    "전류": "Current",
    "temperature": "Temperature",
    "temp": "Temperature",
    "온도": "Temperature",
    "soc": "SOC",
    "state of charge": "SOC",
    "충전율": "SOC",
}


def preprocess(df: pd.DataFrame) -> tuple[pd.DataFrame, list[str]]:
    """
    데이터프레임을 표준 형식으로 전처리합니다.

    Returns
    -------
    (processed_df, warnings)
    """
    warnings: list[str] = []

    # 열 이름 정규화 (소문자 매핑)
    rename_map = {}
    for col in df.columns:
        key = col.strip().lower()
        if key in COLUMN_ALIASES:
            rename_map[col] = COLUMN_ALIASES[key]
    df = df.rename(columns=rename_map)

    # 누락 열 처리
    for col, default in REQUIRED_COLUMNS.items():
        if col not in df.columns:
            df[col] = default
            warnings.append(
                f"'{col}' 열이 없어 기본값({default})으로 채웠습니다."
            )

    # 숫자형 변환
    for col in REQUIRED_COLUMNS:
        df[col] = pd.to_numeric(df[col], errors="coerce")

    # 결측값 처리 (선형 보간 → 앞뒤 채움)
    missing_counts = df[list(REQUIRED_COLUMNS.keys())].isna().sum()
    for col, cnt in missing_counts.items():
        if cnt > 0:
            warnings.append(f"'{col}' 열에 결측값 {cnt}개가 있어 보간 처리했습니다.")
    df = df.interpolate(method="linear").ffill().bfill()

    # 시간 오름차순 정렬
    df = df.sort_values("Time").reset_index(drop=True)

    return df, warnings


# ─────────────────────────────────────────────────────────────────────────────
# 파생 지표 계산
# ─────────────────────────────────────────────────────────────────────────────

def compute_derived(df: pd.DataFrame) -> pd.DataFrame:
    """dT/dt, dV/dt, 상태 레이블 등 파생 열을 추가합니다."""
    df = df.copy()

    # 온도 변화율 (°C/s)
    dt = df["Time"].diff().replace(0, np.nan)
    df["dT_dt"] = df["Temperature"].diff() / dt
    df["dT_dt"] = df["dT_dt"].fillna(0)

    # 전압 변화율 (V/s)
    df["dV_dt"] = df["Voltage"].diff() / dt
    df["dV_dt"] = df["dV_dt"].fillna(0)

    # 롤링 평균 온도 (노이즈 제거용, 윈도우 10포인트)
    df["Temp_smooth"] = df["Temperature"].rolling(window=10, min_periods=1, center=True).mean()

    return df


# ─────────────────────────────────────────────────────────────────────────────
# 상태 분류
# ─────────────────────────────────────────────────────────────────────────────

def classify_status(row: pd.Series, thresholds: dict) -> str:
    """단일 행에 대해 상태를 반환합니다: 'safe' | 'caution' | 'danger'"""
    temp = row["Temperature"]
    dtdt = abs(row.get("dT_dt", 0))
    voltage = row["Voltage"]

    if (
        temp > thresholds["temp_caution_max"]
        or dtdt > thresholds["dtdt_danger"]
        or voltage < thresholds["voltage_min"]
    ):
        return "danger"
    elif temp > thresholds["temp_safe_max"]:
        return "caution"
    else:
        return "safe"


def add_status_column(df: pd.DataFrame, thresholds: dict) -> pd.DataFrame:
    df = df.copy()
    df["Status"] = df.apply(lambda r: classify_status(r, thresholds), axis=1)
    return df


# ─────────────────────────────────────────────────────────────────────────────
# 요약 분석 리포트
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class SafetyReport:
    overall_status: str          # 'safe' | 'caution' | 'danger'
    max_temp: float
    min_voltage: float
    max_dtdt: float
    avg_current: float
    safe_ratio: float            # 전체 중 정상 비율 (0~1)
    caution_ratio: float
    danger_ratio: float
    danger_start_time: Optional[float]   # 위험 최초 진입 시간 (초)
    caution_start_time: Optional[float]  # 주의 최초 진입 시간 (초)
    recommended_current_min: float
    recommended_current_max: float
    max_allowed_temp: float
    warnings: list[str] = field(default_factory=list)


def generate_report(df: pd.DataFrame, thresholds: dict) -> SafetyReport:
    """분석 결과 SafetyReport를 생성합니다."""
    status_counts = df["Status"].value_counts(normalize=True)
    safe_r = status_counts.get("safe", 0.0)
    caution_r = status_counts.get("caution", 0.0)
    danger_r = status_counts.get("danger", 0.0)

    # 전체 상태 판정
    if danger_r > 0:
        overall = "danger"
    elif caution_r > 0:
        overall = "caution"
    else:
        overall = "safe"

    # 최초 위험/주의 진입 시간
    danger_rows = df[df["Status"] == "danger"]
    caution_rows = df[df["Status"] == "caution"]
    danger_start = float(danger_rows["Time"].iloc[0]) if len(danger_rows) > 0 else None
    caution_start = float(caution_rows["Time"].iloc[0]) if len(caution_rows) > 0 else None

    # 안전 권장 전류 범위 (실측 데이터 기반)
    safe_df = df[df["Status"] == "safe"]
    if len(safe_df) > 0:
        rec_min = float(safe_df["Current"].quantile(0.05))
        rec_max = float(safe_df["Current"].quantile(0.95))
    else:
        rec_min = thresholds["current_safe_min"]
        rec_max = thresholds["current_safe_max"]

    return SafetyReport(
        overall_status=overall,
        max_temp=float(df["Temperature"].max()),
        min_voltage=float(df["Voltage"].min()),
        max_dtdt=float(df["dT_dt"].abs().max()),
        avg_current=float(df["Current"].mean()),
        safe_ratio=safe_r,
        caution_ratio=caution_r,
        danger_ratio=danger_r,
        danger_start_time=danger_start,
        caution_start_time=caution_start,
        recommended_current_min=rec_min,
        recommended_current_max=rec_max,
        max_allowed_temp=thresholds["temp_caution_max"],
    )
