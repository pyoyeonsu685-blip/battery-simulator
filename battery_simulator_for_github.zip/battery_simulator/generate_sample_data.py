"""
배터리 열폭주 시뮬레이터 - 샘플 데이터 생성기
정상 → 주의 → 위험(열폭주) 시나리오를 포함한 현실적인 배터리 데이터를 생성합니다.
"""

import numpy as np
import pandas as pd


def generate_battery_data(
    duration_minutes: int = 120,
    sample_rate_sec: int = 10,
    scenario: str = "thermal_runaway",
    seed: int = 42,
) -> pd.DataFrame:
    """
    배터리 테스트 시뮬레이션 데이터를 생성합니다.

    Parameters
    ----------
    duration_minutes : 총 시뮬레이션 시간 (분)
    sample_rate_sec  : 샘플링 간격 (초)
    scenario         : 'normal' | 'caution' | 'thermal_runaway'
    seed             : 난수 시드

    Returns
    -------
    pd.DataFrame with columns: Time, Voltage, Current, Temperature, SOC
    """
    rng = np.random.default_rng(seed)
    total_points = int(duration_minutes * 60 / sample_rate_sec)
    time_arr = np.arange(total_points) * sample_rate_sec  # seconds

    # ── 기본 충방전 프로파일 ──────────────────────────────────────────────
    # 0~40 min: 정상 방전 (CC 구간)
    # 40~80 min: 고율 방전 (주의 구간 진입)
    # 80~120 min: 열폭주 진행 (위험 구간)
    t_min = time_arr / 60.0  # 분 단위

    # 전류 프로파일 (A) — 방전 시 음수 관례 사용
    current = np.where(
        t_min < 40,
        -2.0 + rng.normal(0, 0.05, total_points),
        np.where(
            t_min < 80,
            -4.5 + rng.normal(0, 0.1, total_points),
            -8.0 + rng.normal(0, 0.2, total_points),
        ),
    )

    # SOC 프로파일 (%) — 초기 100%에서 감소
    soc_base = np.clip(100 - (t_min / duration_minutes) * 95, 5, 100)
    soc = soc_base + rng.normal(0, 0.3, total_points)
    soc = np.clip(soc, 0, 100)

    # 전압 프로파일 (V) — SOC와 연동, 리튬이온 특성 반영
    voltage_base = 3.0 + (soc / 100) * 1.2  # 3.0 ~ 4.2 V
    # 고율 방전 시 전압 강하
    voltage_drop = np.where(t_min < 40, 0.0, np.where(t_min < 80, 0.15, 0.35))
    voltage = voltage_base - voltage_drop + rng.normal(0, 0.02, total_points)
    voltage = np.clip(voltage, 2.5, 4.25)

    # 온도 프로파일 (°C)
    if scenario == "normal":
        temp_base = 25 + (t_min / duration_minutes) * 15
        temp = temp_base + rng.normal(0, 0.5, total_points)
        temp = np.clip(temp, 20, 42)

    elif scenario == "caution":
        temp_base = 25 + (t_min / duration_minutes) * 30
        temp = temp_base + rng.normal(0, 0.8, total_points)
        temp = np.clip(temp, 20, 58)

    else:  # thermal_runaway
        # 0~40 min: 정상 상승 (25→40°C)
        # 40~80 min: 가속 상승 (40→60°C, 주의 구간)
        # 80~120 min: 열폭주 (60→120°C, 지수적 상승)
        phase1 = np.clip(25 + (t_min / 40) * 15, 25, 40)
        phase2 = np.clip(40 + ((t_min - 40) / 40) * 20, 40, 60)
        phase3_t = np.clip(t_min - 80, 0, 40)
        phase3 = 60 + 60 * (1 - np.exp(-phase3_t / 15))

        temp_base = np.where(t_min < 40, phase1, np.where(t_min < 80, phase2, phase3))
        temp = temp_base + rng.normal(0, 0.6, total_points)

    df = pd.DataFrame(
        {
            "Time": time_arr,
            "Voltage": np.round(voltage, 4),
            "Current": np.round(current, 4),
            "Temperature": np.round(temp, 2),
            "SOC": np.round(soc, 2),
        }
    )
    return df


def save_sample_excel(path: str = "sample_battery_data.xlsx"):
    """샘플 데이터를 엑셀 파일로 저장합니다."""
    df = generate_battery_data(scenario="thermal_runaway")
    df.to_excel(path, index=False)
    print(f"샘플 데이터 저장 완료: {path}  ({len(df)} rows)")
    return df


if __name__ == "__main__":
    save_sample_excel("/home/ubuntu/battery_simulator/sample_battery_data.xlsx")
